<!-- Modal -->
<div class="modal fade" id="updateStudentModal" tabindex="-1" aria-labelledby="updateStudentModalLabel" aria-hidden="true">
  <form action="" method="post" id="update_student_form">
  	<?php echo csrf_field(); ?>
    <input type="hidden" id="update_id">
  	<div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="updateStudentModalLabel">Update Student</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      	<div class="errMagContainer"></div>

        <div class="form-group">
        	<label for="name">Full Name</label>
        	<input class="form-control" type="text" name="update_name" id="update_name" placeholder="name">
        </div>
        <div class="form-group mt-2">
        	<label for="name">Class</label>
        	<input class="form-control" type="text" name="update_sclass" id="update_sclass" placeholder="class name">
        </div>
        <div class="form-group mt-2">
          <label for="name" >Gender</label>
          <select class="form-select"  name="update_gender" id="update_gender">
            <option value="male">male</option>
            <option value="female">female</option>
            <option value="other">other</option>
          </select>
        </div>
        <div class="form-group mt-2">
        	<label for="name">Roll</label>
        	<input class="form-control" type="text" name="update_roll" id="update_roll" placeholder="roll">
        </div>
        <div class="form-group mt-2">
        	<label for="name">Phone</label>
        	<input class="form-control" type="text" name="update_phone" id="update_phone" placeholder="phone">
        </div>
        <div class="form-group mt-2">
        	<label for="name">Email</label>
        	<input class="form-control" type="text" name="update_email" id="update_email" placeholder="email">
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary update_student">Update</button>
      </div>
    </div>
  </div>
  
  </form>
</div><?php /**PATH D:\Xampp\htdocs\laravel_ajax_project\resources\views/update_student.blade.php ENDPATH**/ ?>