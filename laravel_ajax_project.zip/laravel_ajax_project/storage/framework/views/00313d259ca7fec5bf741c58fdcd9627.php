<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>ajax_project</title>
    <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-md-2">
          
        </div>
        <div class="col-md-8">
          <h2 class="my-5 text-center">Ajax Priject</h2>
          <a href="" class="btn btn-success my-3" data-bs-toggle="modal" data-bs-target="#addStudentModal">Add Student</a>
          <div class="table-data">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th scope="col">SL</th>
                  <th scope="col">Name</th>
                  <th scope="col">Class</th>
                  <th scope="col">Roll</th>
                  <th scope="col">Gender</th>
                  <th scope="col">Phone</th>
                  <th scope="col">Email</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th><?php echo e(++$key); ?></th>
                  <td><?php echo e($row->name); ?></td>
                  <td><?php echo e($row->class); ?></td>
                  <td><?php echo e($row->roll); ?></td>
                  <td><?php echo e($row->gender); ?></td>
                  <td><?php echo e($row->phone); ?></td>
                  <td><?php echo e($row->email); ?></td>
                  <td>
                    <a href=""class="btn btn-primary"><i class="lar la-eye"></i></a>
                    <a href=""
                      class="btn btn-success update_student_form"
                      data-bs-toggle="modal" 
                      data-bs-target="#updateStudentModal"
                      data-id="<?php echo e($row->id); ?>"
                      data-name="<?php echo e($row->name); ?>"
                      data-class="<?php echo e($row->class); ?>"
                      data-roll="<?php echo e($row->roll); ?>"
                      data-phone="<?php echo e($row->phone); ?>"
                      data-email="<?php echo e($row->email); ?>"
                      data-gender="<?php echo e($row->gender); ?>"
                      >
                      <i class="las la-edit"></i>
                    </a>
                    <a href=""
                      class="btn btn-danger delete_student"
                      data-id="<?php echo e($row->id); ?>"
                      >
                      <i class="las la-trash"></i>
                    </a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>

          </div>
        </div>
      </div>
    </div>
    <?php echo $__env->make('add_student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <?php echo $__env->make('update_student', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <?php echo $__env->make('student_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
  </body>
</html><?php /**PATH D:\Xampp\htdocs\laravel_ajax_project\resources\views/index.blade.php ENDPATH**/ ?>