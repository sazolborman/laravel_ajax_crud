<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\controller;
use App\Http\Controllers\student\StudentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/



Route::get('/', [StudentController::class, 'index'])->name('index.home');
Route::post('/add/student', [StudentController::class, 'addstudent'])->name('add.student');
Route::post('/update/student', [StudentController::class, 'updatestudent'])->name('update.student');
Route::post('/delete/student', [StudentController::class, 'deletestudent'])->name('delete.student');