<?php

namespace App\Http\Controllers\student;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\students;
use DB;


class StudentController extends Controller
{
    public function index()
    {
        $student = students::latest()->paginate(10);
        return view('index',compact('student'));
    }
    // __add_student_in_database
    public function addstudent(Request $request)
    {   
        // $request->validate([
        //     'email' => 'required | unique:students',
        //     'name' => 'required',
        //     'sclass' => 'required',
        //     'roll' => 'required',
        //     'phone' => 'required',
            

        // ],
        // [
        //     'name.required'=> 'name is required',
        //     'sclass.required'=> 'class is required',
        //     'roll.required'=> 'roll is required',
        //     'phone.required'=> 'phone is required',
        //     'email.required'=> 'email is required',
        //     'email.unique'=> 'email alrady   taken',                                                                                               
        // ]);

        

            // Perform any additional operations or save the file information to the database
    

        $data = students::insert([

            'name'   => $request->name,
            'class'  =>$request->sclass,
            'roll'   => $request->roll,
            'gender' => $request->gender,
            'phone'  =>$request->phone,
            'email'  =>$request->email,
            

        ]);

         return response()->json([
            'status'=>'success',
        ]);
        
        // $request->validate([
        //     'email' => 'required | unique:students',
        //     'name' => 'required',
        //     'sclass' => 'required',
        //     'roll' => 'required',
        //     'phone' => 'required',
            

        // ],
        // [
        //     'name.required'=> 'name is required',
        //     'sclass.required'=> 'class is required',
        //     'roll.required'=> 'roll is required',
        //     'phone.required'=> 'phone is required',
        //     'email.required'=> 'email is required',
        //     'email.unique'=> 'email alrady taken',                                                                                               
        // ]);

        // $student = new students();

        //    $student->name   = $request->name;
        //    $student->class  =$request->sclass;
        //    $student->roll   = $request->roll;
        //    $student->phone  =$request->phone;
        //    $student->email  =$request->email;
        //     $student->save();
        //     return response()->json([
        //     'status'=>'success',
        // ]);
    }



    // __Update_student_in_database
    public function updatestudent(Request $request)
    {

        // $data = students::insert([

        //     'name'   => $request->name,
        //     'class'  =>$request->sclass,
        //     'roll'   => $request->roll,
        //     'phone'  =>$request->phone,
        //     'email'  =>$request->email,


        // ]);

        // return response()->json($data);
        
        $request->validate([
            'update_email' => 'required | unique:students,name,'.$request->update_id,
            'update_name' => 'required',
            'update_sclass' => 'required',
            'update_roll' => 'required',
            'update_phone' => 'required',
            

        ],
        [
            'update_name.required'=> 'name is required',
            'update_sclass.required'=> 'class is required',
            'update_roll.required'=> 'roll is required',
            'update_phone.required'=> 'phone is required',
            'update_email.required'=> 'email is required',
            'update_email.unique'=> 'email alrady taken',                                                                                               
        ]);

            students::where('id',$request->update_id)->update([
                'name'=>$request->update_name,
                'class'=>$request->update_sclass,
                'roll'=>$request->update_roll,
                'phone'=>$request->update_phone,
                'email'=>$request->update_email,
                'gender'=>$request->update_gender,

            ]);
            return response()->json([
            'status'=>'success',
        ]);
    }

    //__delete student....

    public function deletestudent(Request $request)
    {
        students::find($request->student_id)->delete();
        return response()->json([
            'status'=>'success',
        ]);
    }

}
