<!-- Modal -->
<div class="modal fade" id="addStudentModal" tabindex="-1" aria-labelledby="addStudentModalLabel" aria-hidden="true">
  <form action="" method="post" id="add_student_form">
  	@csrf
  	<div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="addStudentModalLabel">Add Student</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      	<div class="errMagContainer"></div>

        <div class="form-group">
        	<label for="name">Full Name</label>
        	<input class="form-control" type="text" name="name" id="name" placeholder="name">
        </div>
        <div class="form-group mt-2">
        	<label for="name">Class</label>
        	<input class="form-control" type="text" name="sclass" id="sclass" placeholder="class name">
        </div>
        <div class="form-group mt-2">
        	<label for="name">Roll</label>
        	<input class="form-control" type="text" name="roll" id="roll" placeholder="roll">
        </div>
        <div class="form-group mt-2">
          <label for="name" >Gender</label>
          <select class="form-select"  name="gender" id="gender">
            <option value="male">male</option>
            <option value="female">female</option>
            <option value="other">other</option>
          </select>
        </div>

        <div class="form-group mt-2">
        	<label for="name">Phone</label>
        	<input class="form-control" type="text" name="phone" id="phone" placeholder="phone">
        </div>
        <div class="form-group mt-2">
        	<label for="name">Email</label>
        	<input class="form-control" type="text" name="email" id="email" placeholder="email">
        </div>
        

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary add_student">Submit</button>
      </div>
    </div>
  </div>
  
  </form>
</div>