<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>ajax_project</title>
    <link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-md-2">
          
        </div>
        <div class="col-md-8">
          <h2 class="my-5 text-center">Ajax Priject</h2>
          <a href="" class="btn btn-success my-3" data-bs-toggle="modal" data-bs-target="#addStudentModal">Add Student</a>
          <div class="table-data">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th scope="col">SL</th>
                  <th scope="col">Name</th>
                  <th scope="col">Class</th>
                  <th scope="col">Roll</th>
                  <th scope="col">Gender</th>
                  <th scope="col">Phone</th>
                  <th scope="col">Email</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                @foreach($student as $key=>$row)
                <tr>
                  <th>{{++$key}}</th>
                  <td>{{$row->name}}</td>
                  <td>{{$row->class}}</td>
                  <td>{{$row->roll}}</td>
                  <td>{{$row->gender}}</td>
                  <td>{{$row->phone}}</td>
                  <td>{{$row->email}}</td>
                  <td>
                    <a href=""class="btn btn-primary"><i class="lar la-eye"></i></a>
                    <a href=""
                      class="btn btn-success update_student_form"
                      data-bs-toggle="modal" 
                      data-bs-target="#updateStudentModal"
                      data-id="{{$row->id}}"
                      data-name="{{$row->name}}"
                      data-class="{{$row->class}}"
                      data-roll="{{$row->roll}}"
                      data-phone="{{$row->phone}}"
                      data-email="{{$row->email}}"
                      data-gender="{{$row->gender}}"
                      >
                      <i class="las la-edit"></i>
                    </a>
                    <a href=""
                      class="btn btn-danger delete_student"
                      data-id="{{$row->id}}"
                      >
                      <i class="las la-trash"></i>
                    </a>
                  </td>
                </tr>
                @endforeach
              </tbody>
            </table>

          </div>
        </div>
      </div>
    </div>
    @include('add_student');
    @include('update_student');
    @include('student_js');
    
  </body>
</html>