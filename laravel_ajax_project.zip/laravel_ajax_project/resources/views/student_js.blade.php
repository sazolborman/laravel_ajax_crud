
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>  
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
<script src="http://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script> 
    <script>
      $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
    </script>

   <script>
     $(document).ready(function(){
       $(document).on('click','.add_student',function(paramiter){
        paramiter.preventDefault();
        let name = $('#name').val();
        let sclass = $('#sclass').val();
        let roll = $('#roll').val();
        let phone = $('#phone').val();
        let email = $('#email').val();
        let gender = $('#gender').val();
        
         // console.log(name+sclass+gender+roll+phone+email);

          
        
        $.ajax({
          url:"{{route('add.student')}}",
          method:'post',
          dataType:'json',
          data: {name:name,sclass:sclass,roll:roll,gender:gender,phone:phone,email:email},
          success:function(res){
            if(res.status=='success'){
              $('#addStudentModal').modal('hide');
              $('#add_student_form')[0].reset();
              $('.table').load(location.href+' .table');
              Command: toastr["success"]("student Added", "Success")

              toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
              }
              
            }

          },error:function(err){
            let error = err.responseJSON;
            $.each(error.errors,function(index, value){
             $('.errMagContainer').append('<span class="text-danger">'+value+'</span>'+'<br>');


            });

          }


        });
       })

       //__show student info in update form.....

       $(document).on('click','.update_student_form',function(){

          let id = $(this).data('id');
          let name = $(this).data('name');
          let sclass = $(this).data('class');
          let roll = $(this).data('roll');
          let phone = $(this).data('phone');
          let email = $(this).data('email');
          let gender = $(this).data('gender');

          $('#update_id').val(id);
          $('#update_name').val(name);
          $('#update_sclass').val(sclass);
          $('#update_roll').val(roll);
          $('#update_phone').val(phone);
          $('#update_email').val(email);
          $('#update_gender').val(gender);

       });

       //___update students info__

       $(document).on('click','.update_student',function(paramiter){
        paramiter.preventDefault();
        let update_id = $('#update_id').val();
        let update_name = $('#update_name').val();
        let update_sclass = $('#update_sclass').val();
        let update_roll = $('#update_roll').val();
        let update_phone = $('#update_phone').val();
        let update_email = $('#update_email').val();
        let update_gender = $('#update_gender').val();

        // console.log(name+sclass+roll+phone+email);


        
        $.ajax({
          url:"{{route('update.student')}}",
          method:'post',
          dataType:'json',
          data: {update_id:update_id,update_name:update_name,update_sclass:update_sclass,update_roll:update_roll,update_gender:update_gender,update_phone:update_phone,update_email:update_email},
          success:function(res){
            if(res.status=='success'){
              $('#updateStudentModal').modal('hide');
              $('#update_student_form')[0].reset();
              $('.table').load(location.href+' .table');
              Command: toastr["success"]("student updated", "Success")

              toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
              }
            }

          },error:function(err){
            let error = err.responseJSON;
            $.each(error.errors,function(index, value){
             $('.errMagContainer').append('<span class="text-danger">'+value+'</span>'+'<br>');


            });

          }


        });
       })

       //___delete students info__

       $(document).on('click','.delete_student',function(paramiter){
        paramiter.preventDefault();
        let student_id = $(this).data('id');
        if(confirm('Are you Sure to Delete student ??')){

          $.ajax({
          url:"{{route('delete.student')}}",
          method:'post',
          dataType:'json',
          data: {student_id:student_id},
          success:function(res){
            if(res.status=='success'){
              $('.table').load(location.href+' .table');
              Command: toastr["success"]("Student Deleted", "success")
                toastr.options = {
                  "closeButton": true,
                  "debug": false,
                  "newestOnTop": false,
                  "progressBar": true,
                  "positionClass": "toast-top-right",
                  "preventDuplicates": false,
                  "onclick": null,
                  "showDuration": "300",
                  "hideDuration": "1000",
                  "timeOut": "5000",
                  "extendedTimeOut": "1000",
                  "showEasing": "swing",
                  "hideEasing": "linear",
                  "showMethod": "fadeIn",
                  "hideMethod": "fadeOut"
                }
            }

          }


        });

        }

       
       })

     });
   </script>